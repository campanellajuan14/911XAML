# 9-1-1 Reality Simulator — Active Skin Prototype

WPF / .NET 6 prototype for the dark **active screen** sidebar + center hero panel
of the 9-1-1 Reality Simulator instructor console. Built strictly in XAML using
`Grid`, `Style`, `ControlTemplate`, and `ResourceDictionary` — no third-party UI
framework, no code-behind visual logic, no WinForms, no HTML/CSS.

## Scope

This is the $200 / 48-hour technical prototype, not the full milestone.

In scope (delivered):

- **Dark active screen** — header bar, sidebar, center hero panel
- **Sidebar** — top role/computer label, primary navigation, Training Resources
  section, System section (Restart / Shutdown), and a **free-form MODEL input**
  at the bottom (per the SOW's "fillable space - BASIC PLUS PROCOMM")
- **Hero panel** — 911 headset badge, "9-1-1 REALITY SIMULATOR" title, ECG line,
  "START SIMULATION" label, orange START button, system status text block
- **Cityscape mid-layer** with gradient opacity mask per the *City Scape for all*
  guidance (top + bottom fade, reduced opacity, sits between background and
  foreground content)
- **Hover / pressed / disabled** states on the START button and sidebar items
- **Storyboard animation** — looping 2.4s opacity pulse on the ECG waveform
  (`SineEase` in/out) plus button hover/press transitions
- **DPI awareness** — `PerMonitorV2` declared in `app.manifest`,
  `UseLayoutRounding="True"` and `SnapsToDevicePixels="True"` on the window

Explicitly out of scope for this prototype:

- Light "folder view" screen
- The four inactive-monitor screens
- Any backend wiring (start/restart/shutdown are inert)

## How to build & run

Requires Visual Studio 2022 (17.4+) **or** the .NET 6 SDK on Windows.

```powershell
cd NineOneOneReality.Launcher
dotnet build
dotnet run --project NineOneOneReality.Launcher
```

Or just open `NineOneOneReality.Launcher.sln` in Visual Studio and press F5.

## File organization

```
NineOneOneReality.Launcher/
|-- NineOneOneReality.Launcher.sln
\-- NineOneOneReality.Launcher/
    |-- App.xaml                 # merges all global resource dictionaries
    |-- App.xaml.cs              # startup + global exception logging
    |-- app.manifest             # PerMonitorV2 DPI awareness
    |
    |-- Themes/
    |   |-- Brushes.Brand.xaml   # theme-independent brand colors (orange, etc.)
    |   |-- Theme.Dark.xaml      # dark palette (merged into the active window)
    |   |-- Theme.Light.xaml     # parallel light palette (kept for future use)
    |   |-- Typography.xaml      # Montserrat font + text styles
    |   \-- Effects.xaml         # reusable DropShadowEffects
    |
    |-- Controls/                # ControlTemplate + Style for each component
    |   |-- HeaderBar.xaml
    |   |-- NavButton.xaml       # sidebar item template w/ hover/pressed/selected/disabled
    |   |-- PrimaryButton.xaml   # START button template w/ hover/pressed/disabled
    |   \-- StatusPill.xaml      # SYSTEM STATUS / SIMULATION READY pills
    |
    |-- Animations/
    |   \-- MicroInteractions.xaml  # shared Duration + EasingFunction resources
    |
    |-- Resources/
    |   |-- Icons.xaml           # vector Geometry resources for every icon
    |   |-- Fonts/Montserrat-*.ttf
    |   \-- Images/              # source-of-truth design references and reserved
    |                            # slot for a future cityscape-silhouette.png
    |
    \-- Views/
        |-- ActiveDarkWindow.xaml      # the prototype screen
        \-- ActiveDarkWindow.xaml.cs   # only InitializeComponent()
```

The split is deliberate: theme palette, brand color, typography, control
template, and animation parameters can each be edited in isolation without
touching the view, and every key the view consumes is exposed via
`StaticResource` / `DynamicResource` lookups.

## Theming

The dark palette is merged at the **window** level
(`ActiveDarkWindow.xaml.Window.Resources`), not at App level. To produce a
light variant of the same screen, a sibling window swaps `Theme.Dark.xaml`
for `Theme.Light.xaml` and reuses every other dictionary unchanged. Both
theme files declare the same set of keys (e.g. `Brush.Theme.Background`,
`Brush.Theme.Sidebar.ItemHover`) so control templates that bind via
`DynamicResource` re-resolve automatically.

Brand colors that must remain constant across themes (e.g. the safety orange
`#FFFF7A00`, "system READY" green) live in `Brushes.Brand.xaml`.

## Animations

| Element        | Trigger                | Animation                                      |
| -------------- | ---------------------- | ---------------------------------------------- |
| ECG pulse line | `Loaded` event         | `Opacity` 0.55 → 1.0, 1.2s, `SineEase`, loop, auto-reverse |
| START button   | `IsMouseOver`          | `Opacity` 1.0 → 0.92 over 120ms                |
| START button   | `IsPressed`            | `RenderTransform` scale 1.0 → 0.97 over 80ms   |
| START button   | `IsEnabled = False`    | static disabled brush + reduced opacity        |
| Sidebar item   | `IsMouseOver`          | background swap to `Brush.Theme.Sidebar.ItemHover` |
| Sidebar item   | `IsChecked` (selected) | left orange indicator + filled background      |

The ECG pulse is the hero animation called out in the SOW ("ECG opacity pulse
**or** button hover transition" — both are present).

## DPI verification

The application targets the 1920×1080 design canvas and is `PerMonitorV2`
DPI-aware. To capture the three required scaling screenshots on Windows:

1. Right-click the desktop → **Display settings**
2. Set **Scale** to `100%`. **Sign out and sign back in** (required - WPF will
   otherwise report the previous DPI).
3. Run the launcher (`dotnet run` or the published exe), then either:
   - press `Win`+`Shift`+`S`, choose **Window snip**, paste into Paint,
     save as `screenshots/dpi-100.png`, **or**
   - run the bundled helper:
     `powershell -ExecutionPolicy Bypass -File .\tools\Capture-DpiScreenshot.ps1`
     which auto-names the file from the detected DPI.
4. Repeat for `125%` and `150%`.

Because the layout uses logical pixels with `UseLayoutRounding="True"` and
`SnapsToDevicePixels="True"`, the layout grid stays identical at every scale —
only text and icon glyph rasterization re-renders for the new device pixel
density. No "blurry text" or layout shift is expected.

## Known notes for the reviewer

- `App.xaml.cs` attaches dispatcher / domain / task-scheduler exception handlers
  that always write to `startup-error.log` next to the executable; in `DEBUG`
  builds they additionally surface a `MessageBox` so a developer can see the
  stack trace immediately. This guards against silent failures of `WinExe`
  apps and is intentional for a prototype.
- `Theme.Light.xaml` is included to demonstrate the parallel-key theming
  contract. No window currently consumes it; it is the seed for the full
  Milestone 1 light variants.
- The hero panel background is built from **vector XAML only** (a tiled
  `DrawingBrush` grid + a `RadialGradientBrush` spotlight + a vignette).
  The original "cityscape" reference PNG was a flattened render of the
  whole mockup with the title, ECG line, START button, and status text
  baked into the pixels - using it as a background would visibly ghost
  behind the real XAML controls. The City Scape doc calls for a
  **transparent silhouette PNG** as the mid-layer; a slot for it is
  reserved at L4 in `ActiveDarkWindow.xaml` (commented out, ready to
  uncomment once the artist supplies `cityscape-silhouette.png`).
